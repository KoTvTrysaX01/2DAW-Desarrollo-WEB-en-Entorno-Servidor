
INSERT INTO libros ( id, titulo, autor ) VALUES 
  (1, 'Macbeth', 'William Shakespeare'),
  (2, 'La Celestina (Tragicomedia de Calisto y Melibea)', 'Fernando de Rojas'),
  (3, 'El Lazarillo de Tormes', 'Anónimo'),
  (4, '20.000 Leguas de Viaje Submarino', 'Julio Verne'),
  (5, 'Alicia en el País de las Maravillas', 'Lewis Carrol'),
  (6, 'Cien Años de Soledad', 'Gabriel García Márquez'),
  (7, 'La tempestad', 'William Shakespeare');
