
    <section class="container my-5 p-5 rounded bg-info-subtle border border-info shadow">
      <h1 class="mb-4 text-center text-primary fw-bold">🌅 MARES</h1>
		<p>Un mar es una masa de agua salada de tamaño menor que el océano, así como también el conjunto de la masa de agua salada que cubre la mayor parte de la superficie del planeta Tierra, incluyendo océanos y mares menores.</p>

		<p>El término mar también se utiliza para designar algunos grandes lagos salobres, como el mar Caspio, el mar Muerto o el mar de Aral. Se habla entonces de mar cerrado o interior, pero el término correcto es lago endorreico. </p>
    </section>


