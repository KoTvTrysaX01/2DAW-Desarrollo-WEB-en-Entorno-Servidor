
    <section class="container my-5 p-5 rounded bg-info-subtle border border-info shadow">
      <h1 class="mb-4 text-center text-primary fw-bold">💧 RÍOS</h1>
		<p>Un río es una corriente natural de agua que fluye con continuidad. Posee un caudal determinado, rara vez es constante a lo largo del año, y desemboca en el mar, en un lago o en otro río, en cuyo caso se denomina afluente. La parte final de un río es su desembocadura. Algunas veces terminan en zonas desérticas donde sus aguas se pierden por infiltración y evaporación por las intensas temperaturas.</p>
    </section>


