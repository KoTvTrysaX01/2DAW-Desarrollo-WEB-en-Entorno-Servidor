<?php
	$config=array();
	$config['head_title']="Ríos";
	$config['nav_title']="🌍 Geografía";
	$config['nav_active']="rios";
?>
<!DOCTYPE html>
<html lang="es">
<?php
	include "./inc/include_head.php";
?>
<body class="d-flex flex-column min-vh-100 bg-light">

  <?php
	include "./inc/include_nav.php";
  ?>
  <!-- Contenido principal -->
  <main class="flex-fill d-flex align-items-center">
    <section class="container my-5 p-5 rounded bg-info-subtle border border-info shadow">
      <h1 class="mb-4 text-center text-primary fw-bold">💧 RÍOS</h1>
		<p>Un río es una corriente natural de agua que fluye con continuidad. Posee un caudal determinado, rara vez es constante a lo largo del año, y desemboca en el mar, en un lago o en otro río, en cuyo caso se denomina afluente. La parte final de un río es su desembocadura. Algunas veces terminan en zonas desérticas donde sus aguas se pierden por infiltración y evaporación por las intensas temperaturas.</p>
    </section>
  </main>

  <?php
	include "./inc/include_footer.php";
	
	include "./inc/include_scripts.php";
  ?>


</body>
</html>

