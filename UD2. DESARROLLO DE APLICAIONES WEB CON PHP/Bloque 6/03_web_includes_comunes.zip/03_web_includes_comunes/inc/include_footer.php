  <!-- Pie de página -->
  <footer class="text-white text-center py-4 bg-primary bg-gradient">
    <p class="mb-1">📍 La Cerámica, 24 - 03010 ALICANTE</p>
    <p class="mb-1">📞 Telf: 965936540</p>
    <p class="mb-0">🌐 www.iesdoctorbalmis.com</p>
  </footer>